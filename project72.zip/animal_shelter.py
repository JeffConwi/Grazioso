from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self):
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections.
        # This is hard-wired to use the aac database, the 
        # animals collection, and the aac user.
        # Definitions of the connection string variables are
        # unique to the individual Apporto environment.
        #
        # You must edit the connection variables below to reflect
        # your own instance of MongoDB!
        #
        # Connection Variables
        #
        USER = 'aacuser'
        PASS = 'asdf123snhu'
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 31675
        DB = 'AAC'
        COL = 'animals'
        #
        # Initialize Connection
        #
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT))
        self.database = self.client['%s' % (DB)]
        self.collection = self.database['%s' % (COL)]

    def create(self, data):
        """
        Create a new document in the animals collection
        :param data: Dictionary of animal data
        :return: True if successful, False otherwise
        """
        if data is not None:
            try:
                result = self.collection.insert_one(data)
                return result.acknowledged
            except Exception as e:
                print(f"An error occurred: {e}")
                return False
        else:
            raise Exception("Nothing to save, because data parameter is empty")

    def read(self, query):
        """
        Read documents from the animals collection
        :param query: Dictionary of query parameters
        :return: List of matching documents, or empty list if none found
        """
        try:
            cursor = self.collection.find(query)
            return list(cursor)
        except Exception as e:
            print(f"An error occurred: {e}")
            return []
        
    def update(self, query, new_values):
        """
        Update documents in the animals collection
        :param query: Dictionary of query parameters to find documents to update
        :param new_values: Dictionary of new values to set
        :return: Number of documents modified
        """
        try:
            result = self.collection.update_many(query, {"$set": new_values})
            return result.modified_count
        except Exception as e:
            print(f"An error occurred: {e}")
            return 0

    def delete(self, query):
        """
        Delete documents from the animals collection
        :param query: Dictionary of query parameters to find documents to delete
        :return: Number of documents deleted
        """
        try:
            result = self.collection.delete_many(query)
            return result.deleted_count
        except Exception as e:
            print(f"An error occurred: {e}")
            return 0
